//cacha variables del form de la pag anterior:
cadVariables = location.search.substring(1,location.search.length);
arrVariables = cadVariables.split("&");
for (i=0; i<arrVariables.length; i++) {
  arrVariableActual = arrVariables[i].split("=");
  if (isNaN(parseFloat(arrVariableActual[1])))
    eval(arrVariableActual[0]+"='"+unescape(arrVariableActual[1])+"';");
  else
    eval(arrVariableActual[0]+"="+arrVariableActual[1]+";");
}

var PCAEditar = '';  //esta es la var que se envía desde el boton editar
const linkNuevaPC = document.getElementById("linkNuevaPC");
linkNuevaPC.href=`javascript:sucuAEditar = '${sucuAEditar}'; pasarVariables('Computadoras.html', 'sucuAEditar')
`;

//SDK Firebase y config 

var config = {
        apiKey: "AIzaSyBIWCjxJ4R4tsm1b-x1109xnMmPJVhPEFk",
        authDomain: "inventario-sucursales.firebaseapp.com",
        databaseURL: "https://inventario-sucursales.firebaseio.com",
        projectId: "inventario-sucursales",
        storageBucket: "inventario-sucursales.appspot.com",
        messagingSenderId: "27630270497"
        };
        firebase.initializeApp(config);

//fin firebase config

//----------------Clases
class Sucursal {
	constructor(nombre,direccion,coordinador){
	this.nombre = nombre;
	this.direccion = direccion;
	this.coordinador = coordinador;
	}
}

class Computadora {
    constructor(marca, modelo, procesador, HDD, RAM, asignada, hostname, serialnumber){
  
    this.serialnumber = serialnumber;
    this.HDD = HDD;
    this.asignada = asignada;
    this.hostname = hostname;
    this.marca = marca;
    this.modelo = modelo;
    this.procesador = procesador;
    this.serialnumber = serialnumber;
    }

}

class UI{

	resetForm() {
        document.getElementById('formEdicion').reset();
        document.getElementById('selectComputadoras').value = '';
    }

	mostrarMensajeCarga(mensaje,css){

        const div = document.createElement('div');  		//creo un Div
        div.className = `alert alert-${css} mt-2`;			//le asigno clase para discriminar CSS
        div.appendChild(document.createTextNode(mensaje));	//inserto el texto dentro del div 
        // Mostrar
        const container = document.querySelector('.container');
        const app = document.querySelector('#App');
        // Insertar mensaje en la UI
        container.insertBefore(div, app);
        // Quitar el mensaje tras 3 segundos
        setTimeout(function () {
            document.querySelector('.alert').remove();
        }, 2000);
    }

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// funciones hacia la base de datos
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 

function updateSucursalBase(arbolitoSucursal) {

    var ClaveSucursal = sucuAEditar;

    var updates = {};
    updates['/informe-sucursal/Sucursales/' + ClaveSucursal] = arbolitoSucursal;

    return firebase.database().ref().update(updates);
    }  
function agregarPCSucursalBase(arbolitoComputadora) {

    const keyPCElegida = document.getElementById("selectComputadoras").value;
    var updates = {};
    updates['informe-sucursal/Sucursal-PC/' + sucuAEditar +'/'+ keyPCElegida ] = arbolitoComputadora;

    return firebase.database().ref().update(updates);
    }  



    /////////////////////////////////////////      MAIN MAIN MAIN             //////////////////////////////////////////////////


//////////Eventos que involucran a la  Base
    
//----------------BOTONES--------------    

document.getElementById('botonActualizarEnBase').addEventListener('click', function ActualizarSucuEnBase(elemento){
        
        const nombre = document.getElementById('nombre').value,
            direccion = document.getElementById('direccion').value,
            coordinador = document.getElementById('coordinador').value;

        objetoSucursal = new Sucursal(nombre,direccion,coordinador);
        
        const ui = new UI(); //creo una UI para mostrar mensajes, y borrar el contenido de más

        //validacion 
        if (nombre === '' || direccion === '' || coordinador === '') {
            ui.mostrarMensajeCarga('Debe completar todos los campos', 'danger');
        }else {
                                        // Guardando en BASE
        updateSucursalBase(objetoSucursal)
        ui.mostrarMensajeCarga('Elemento añadido con éxito.', 'success');

        }
        //ui.resetForm(); //como el form me lo llena el evento de base no hace falta resetearlo.
        // elemento.preventDefault();

    });


document.getElementById('botonMeterEnBase').addEventListener('click', function meterCompuEnBase(elemento){
        
        const keyPCElegida =  document.getElementById('selectComputadoras').value;
                //aca tengo que conseguir la data de PC, para crear el objeto
        var stringPCElegida = '/informe-sucursal/PC/'+keyPCElegida;
        var refPCElegida = firebase.database().ref().child(stringPCElegida);



        var objetoPC = new Computadora;
        refPCElegida.on('value', snap =>{
            objetoPC.HDD  = snap.child('HDD').val();
            objetoPC.RAM  = snap.child('RAM').val();
            objetoPC.asignada  = snap.child('asignada').val();
            objetoPC.hostname  = snap.child('hostname').val();
            objetoPC.marca  = snap.child('marca').val();
            objetoPC.modelo  = snap.child('modelo').val();
            objetoPC.procesador  = snap.child('procesador').val();
            objetoPC.serialnumber  = snap.child('serialnumber').val();

        });
      
        
        const ui = new UI(); //creo una UI para mostrar mensajes, y borrar el contenido de más

        //validacion 
        if (keyPCElegida === '') {
            ui.mostrarMensajeCarga('Debe completar todos los campos', 'danger');
        }else {
                                        // Guardando en BASE
        agregarPCSucursalBase(objetoPC);
        ui.mostrarMensajeCarga('Asociacion realizada con éxito.', 'success');

        }
        ui.resetForm();

    });


//////boton volver
// document.addEventListener('click',"botonVolver",)
//--------------------FIN BOTONES


//----------------SINCRONIZACIÓN / MUESTRA DE ELEMENTO DE LA BASE--------------   
//1- constantes:
const listaComputadoras = document.getElementById("listaComputadoras");
const listaCoordi = document.getElementById("coordinador");  //creo la lista de coordinadores para Autocompletar de formulario
const selectComputadoras = document.getElementById("selectComputadoras");
//1- referencio base

var refListaComputadorasLibres = firebase.database().ref().child('/informe-sucursal/PC');
var refListaCoordinadores = firebase.database().ref().child('/informe-sucursal/Coordinadores');


var stringSucuPC = 'informe-sucursal/Sucursal-PC/'+sucuAEditar;
var stringKey = '/informe-sucursal/Sucursales/'+sucuAEditar;
var refListaPCSucursal = firebase.database().ref().child(stringSucuPC);
const refSucuAEditar = firebase.database().ref().child(stringKey);

//2- Eventos Scincronización
refListaPCSucursal.on('child_added', snap => {  //2.1.1 -Escucha nuevos Childs de COMPUTADORAS asociadas a la Sucursal Seleccionada
    
    const tarjeta = document.createElement('div');
        tarjeta.id=snap.key;
        tarjeta.innerHTML = `
            <div class="card text-center mb-4">
                <div class="card-body">
                    <strong><font size="5">${snap.val().hostname} </font> </strong>
                    <br>
                    <strong>Modelo</strong>: ${snap.val().modelo} - 
                    <strong>Serial</strong>: ${snap.val().serialnumber}     
                    <br>
                    <!-- a href="#" class="btn btn-dark" name="edit">Ver</a -->
                    <a href="javascript:PCAEditar = '${snap.key}' ;pasarVariables('EdicionPc.html', 'PCAEditar')" class="btn btn-info" name="edit">Editar</a>
                    <a href="#" class="btn btn-danger" name="delete">Borrar</a>
                </div>
            </div>
        `;
        listaComputadoras.appendChild(tarjeta);

});

refListaPCSucursal.on('child_changed', snap => {        //2.1.2 -Escucha modificaciones Childs COMPUTADORAS asociadas a la Sucursal Seleccionada
    const tarjetaChanged = document.getElementById(snap.key);
    tarjetaChanged.innerHTML = `
            <div class="card text-center mb-4">
                <div class="card-body">
                    <strong><font size="5">${snap.val().hostname} </font> </strong>
                    <br>
                    <strong>Modelo</strong>: ${snap.val().modelo} - 
                    <strong>Serial</strong>: ${snap.val().serialnumber}     
                    <br>
                    <a href="#" class="btn btn-dark" name="edit">Ver</a>
                    <a href="javascript:PCAEditar = '${snap.key}'; sucuAEditar = '${sucuAEditar}' ;pasarVariables('EdicionPc.html', 'PCAEditar,sucuAEditar')" class="btn btn-info" name="edit">Editar</a>
                    <a href="#" class="btn btn-danger" name="delete">Borrar</a>
                </div>
            </div>
        `;
});

refListaPCSucursal.on('child_removed', snap =>{         //2.1.2 -Escucha eliminacion Childs de COMPUTADORAS asociadas a la Sucursal Seleccionada
    const tarjetaToRemove = document.getElementById(snap.key);
    tarjetaToRemove.remove();
});

                         
refListaCoordinadores.on('child_added', snap =>{ //2.2 Escucha nuevos Childs de COORDINADORES
    const itemCoordi = document.createElement('option');
    itemCoordi.id = snap.key;
    itemCoordi.value = snap.val().nombre;
    itemCoordi.innerText = snap.val().nombre;

    listaCoordi.appendChild(itemCoordi); 
});

refListaComputadorasLibres.on('child_added', snap =>{ //2.2 Escucha nuevos Childs de COMPUTADORAS LIBRES
    const itemCompu = document.createElement('option');
    itemCompu.id = snap.key;
    itemCompu.value = snap.key;
    itemCompu.innerText = snap.val().serialnumber;

    selectComputadoras.appendChild(itemCompu); 
});


//LLeno el formulario Edición de SUCURSAL con los elementos de la sucursal de base

const formEdicion = document.getElementById("formEdicion");
var tituloSucu = document.getElementById("tituloSucu");

var nombreTraido = document.getElementById("nombre");
var direccionTraido = document.getElementById("direccion");
var coordinadorTraido = document.getElementById("coordinador");
refSucuAEditar.on('value', snap => {
    tituloSucu.innerText  = snap.child('nombre').val();

    nombre.value = snap.child('nombre').val();
    direccionTraido.value = snap.child('direccion').val();
    coordinadorTraido.value = snap.child('coordinador').val();
});


////////////////////////////////funciones de interaccion de FORMS

function pasarVariables(pagina, nombres) {
  pagina +="?";
  nomVec = nombres.split(",");
  for (i=0; i<nomVec.length; i++)
    pagina += nomVec[i] + "=" + escape(eval(nomVec[i]))+"&";
  pagina = pagina.substring(0,pagina.length-1);
  location.href=pagina;
}



