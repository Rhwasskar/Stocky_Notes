//cacha variables del form de la pag anterior:
cadVariables = location.search.substring(1,location.search.length);
arrVariables = cadVariables.split("&");
for (i=0; i<arrVariables.length; i++) {
  arrVariableActual = arrVariables[i].split("=");
  if (isNaN(parseFloat(arrVariableActual[1])))
    eval(arrVariableActual[0]+"='"+unescape(arrVariableActual[1])+"';");
  else
    eval(arrVariableActual[0]+"="+arrVariableActual[1]+";");
}


const linkVolver = document.getElementById("linkVolver");
linkVolver.href = `javascript:sucuAEditar = '${sucuAEditar}'; pasarVariables('EdicionSucursal.html', 'sucuAEditar')
`;
//SDK Firebase y config


var config = {
        apiKey: "AIzaSyBIWCjxJ4R4tsm1b-x1109xnMmPJVhPEFk",
        authDomain: "inventario-sucursales.firebaseapp.com",
        databaseURL: "https://inventario-sucursales.firebaseio.com",
        projectId: "inventario-sucursales",
        storageBucket: "inventario-sucursales.appspot.com",
        messagingSenderId: "27630270497"
        };
        firebase.initializeApp(config);

//fin firebase config




//----------------Clases
class Computadora {
    constructor(marca,modelo,serialnumber){
  
    this.serialnumber = serialnumber;
    this.marca = marca;
    this.modelo = modelo;
    }

}
//---------------Constructor UI

class UI{

	resetForm() {
        document.getElementById('formCarga').reset();
    }

	mostrarMensajeCarga(mensaje,css){

        const div = document.createElement('div');  		//creo un Div
        div.className = `alert alert-${css} mt-2`;			//le asigno clase para discriminar CSS
        div.appendChild(document.createTextNode(mensaje));	//inserto el texto dentro del div 
        // Mostrar
        const container = document.querySelector('.container');
        const app = document.querySelector('#App');
        // Insertar mensaje en la UI
        container.insertBefore(div, app);
        // Quitar el mensaje tras 3 segundos
        setTimeout(function () {
            document.querySelector('.alert').remove();
        }, 2000);
    }

}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// funciones hacia la base de datos
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 

function agregarCompuBase(arbolitoComputadora) {

    var ClaveNuevaPC = firebase.database().ref().child('/informe-sucursal/PC').push().key;


    var updates = {};
    updates['/informe-sucursal/PC/' + ClaveNuevaPC] = arbolitoComputadora;

    return firebase.database().ref().update(updates);
    }  



    /////////////////////////////////////////      MAIN MAIN MAIN             //////////////////////////////////////////////////


//////////Eventos que involucran a la  Base
    
//----------------BOTONES--------------    

document.getElementById('botonMeterEnBase').addEventListener('click', function meterCompuBase(elemento){
        
        const marca = document.getElementById('marca').value,
            modelo = document.getElementById('modelo').value,
            serialnumber = document.getElementById('serialnumber').value;
            // procesador = document.getElementById('procesador').value,
            // RAM = document.getElementById('RAM').value;
            // HDD = document.getElementById('HDD').value;


        objetoPC = new Computadora(marca,modelo,serialnumber);
        
        const ui = new UI(); //creo una UI para mostrar mensajes, y borrar el contenido de más

        //validacion 
        if (marca === '' || modelo === '' || serialnumber === '') {
            ui.mostrarMensajeCarga('Debe tener marca modelo y serial al menos', 'danger');
        }else {
                                        // Guardando en BASE
        agregarCompuBase(objetoPC);
        ui.mostrarMensajeCarga('Elemento añadido con éxito.', 'success');

        }
        ui.resetForm();
        // elemento.preventDefault();

    });


//----------------SINCRONIZACIÓN / MUESTRA DE ELEMENTO DE LA BASE--------------   
//1- constantes:
const listaComputadoras = document.getElementById('listaComputadoras');

//1- referencio base
var refListaComputadoras = firebase.database().ref().child('/informe-sucursal/PC');

//2- Eventos Scincronización
    //2.1- Childs de PCS 
refListaComputadoras.on('child_added', snap => {  //2.1.1Escucha nuevos Childs de PCS
    
    const tarjeta = document.createElement('div');
        tarjeta.id=snap.key;
        tarjeta.innerHTML = `
            <div class="card text-center mb-4">
                <div class="card-body">
                    <strong><font size="5">${snap.val().serialnumber} </font> </strong>
                    <br>
                    <strong>Marca</strong>: ${snap.val().marca} - 
                    <strong>Modelo</strong>: ${snap.val().modelo}     
                    <br>
                    <!-- a href="#" class="btn btn-dark" name="edit">Ver</a -->
                    <a href="javascript:sucuAEditar = '${snap.key}' ;pasarVariables('EdicionPC.html', 'sucuAEditar')" class="btn btn-info" name="edit">Editar</a>
                    <a href="#" class="btn btn-danger" name="delete">Borrar</a>
                </div>
            </div>
        `;
        listaComputadoras.appendChild(tarjeta);

});

refListaComputadoras.on('child_changed', snap=>{                  //2.1.2 - Escucha Cambios en los Childs de PCS
    const tarjetaChanged = document.getElementById(snap.key);
    tarjetaChanged.innerHTML = `
            <div class="card text-center mb-4">
                <div class="card-body">
                    <strong><font size="5">${snap.val().serialnumber} </font> </strong>
                    <br>
                    <strong>Modelo</strong>: ${snap.val().marca} - 
                    <strong>Numero de serie</strong>: ${snap.val().modelo}     
                    <br>
                    <!-- a href="#" class="btn btn-dark" name="edit">Ver</a -->
                    <a href="javascript:sucuAEditar = '${snap.key}' ;pasarVariables('EdicionPC.html', 'sucuAEditar')" class="btn btn-info" name="edit">Editar</a>
                    <a href="#" class="btn btn-danger" name="delete">Borrar</a>
                </div>
            </div>
        `;
});

refListaComputadoras.on('child_removed', snap =>{
    const tarjetaToRemove = document.getElementById(snap.key);
    tarjetaToRemove.remove();
});

                         

////////////////////////////////funciones de interaccion de FORMS

function pasarVariables(pagina, nombres) {
  pagina +="?";
  nomVec = nombres.split(",");
  for (i=0; i<nomVec.length; i++)
    pagina += nomVec[i] + "=" + escape(eval(nomVec[i]))+"&";
  pagina = pagina.substring(0,pagina.length-1);
  location.href=pagina;
}