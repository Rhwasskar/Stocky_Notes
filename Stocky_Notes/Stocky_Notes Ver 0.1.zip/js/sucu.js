var sucuAEditar = '';  //esta es la var que se envía desde el boton editar

//SDK Firebase y config


var config = {
        apiKey: "AIzaSyBIWCjxJ4R4tsm1b-x1109xnMmPJVhPEFk",
        authDomain: "inventario-sucursales.firebaseapp.com",
        databaseURL: "https://inventario-sucursales.firebaseio.com",
        projectId: "inventario-sucursales",
        storageBucket: "inventario-sucursales.appspot.com",
        messagingSenderId: "27630270497"
        };
        firebase.initializeApp(config);

//fin firebase config




//----------------Clases
class Sucursal {
	constructor(nombre,direccion,coordinador){
	this.nombre = nombre;
	this.direccion = direccion;
	this.coordinador = coordinador;
	}
}

//---------------Constructor UI

class UI{

	resetForm() {
        document.getElementById('formCarga').reset();
    }

	mostrarMensajeCarga(mensaje,css){

        const div = document.createElement('div');  		//creo un Div
        div.className = `alert alert-${css} mt-2`;			//le asigno clase para discriminar CSS
        div.appendChild(document.createTextNode(mensaje));	//inserto el texto dentro del div 
        // Mostrar
        const container = document.querySelector('.container');
        const app = document.querySelector('#App');
        // Insertar mensaje en la UI
        container.insertBefore(div, app);
        // Quitar el mensaje tras 3 segundos
        setTimeout(function () {
            document.querySelector('.alert').remove();
        }, 2000);
    }

}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// funciones hacia la base de datos
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 

function agregarSucursalBase(arbolitoSucursal) {

    var ClaveNuevaSucursal = firebase.database().ref().child('/informe-sucursal/Sucursales').push().key;


    var updates = {};
    updates['/informe-sucursal/Sucursales/' + ClaveNuevaSucursal] = arbolitoSucursal;

    return firebase.database().ref().update(updates);
    }  



    /////////////////////////////////////////      MAIN MAIN MAIN             //////////////////////////////////////////////////


//////////Eventos que involucran a la  Base
    
//----------------BOTONES--------------    

document.getElementById('botonMeterEnBase').addEventListener('click', function meterSucuEnBase(elemento){
        
        const nombre = document.getElementById('nombre').value,
            direccion = document.getElementById('direccion').value,
            coordinador = document.getElementById('coordinador').value;

        objetoSucursal = new Sucursal(nombre,direccion,coordinador);
        
        const ui = new UI(); //creo una UI para mostrar mensajes, y borrar el contenido de más

        //validacion 
        if (nombre === '' || direccion === '' || coordinador === '') {
            ui.mostrarMensajeCarga('Debe completar todos los campos', 'danger');
        }else {
                                        // Guardando en BASE
        agregarSucursalBase(objetoSucursal)
        ui.mostrarMensajeCarga('Elemento añadido con éxito.', 'success');

        }
        ui.resetForm();
        // elemento.preventDefault();

    });


//----------------SINCRONIZACIÓN / MUESTRA DE ELEMENTO DE LA BASE--------------   
//1- constantes:
 const listaCoordi = document.getElementById("coordinador");  //creo la lista de coordinadores para Autocompletar de formulario

//1- referencio base
var refListaSucursales = firebase.database().ref().child('/informe-sucursal/Sucursales');
var refListaCoordinadores = firebase.database().ref().child('/informe-sucursal/Coordinadores')

//2- Eventos Scincronización
    //2.1- Childs de Sucursales 
refListaSucursales.on('child_added', snap => {  //2.1.1Escucha nuevos Childs de SUCURSALES
    
    const tarjeta = document.createElement('div');
        tarjeta.id=snap.key;
        tarjeta.innerHTML = `
            <div class="card text-center mb-4">
                <div class="card-body">
                    <strong><font size="5">${snap.val().nombre} </font> </strong>
                    <br>
                    <strong>Direccion</strong>: ${snap.val().direccion} - 
                    <strong>Coordinador</strong>: ${snap.val().coordinador}     
                    <br>
                    <!-- a href="#" class="btn btn-dark" name="edit">Ver</a -->
                    <a href="javascript:sucuAEditar = '${snap.key}' ;pasarVariables('EdicionSucursal.html', 'sucuAEditar')" class="btn btn-info" name="edit">Editar</a>
                    <a href="#" class="btn btn-danger" name="delete">Borrar</a>
                </div>
            </div>
        `;
        listaSucursales.appendChild(tarjeta);

});

refListaSucursales.on('child_changed', snap=>{                  //2.1.2 - Escucha Cambios en los Childs de SUCURSALES
    const tarjetaChanged = document.getElementById(snap.key);
    tarjetaChanged.innerHTML = `
            <div class="card text-center mb-4">
                <div class="card-body">
                    <strong><font size="5">${snap.val().nombre} </font> </strong>
                    <br>
                    <strong>Direccion</strong>: ${snap.val().direccion} - 
                    <strong>Coordinador</strong>: ${snap.val().coordinador}     
                    <br>
                    <!-- a href="#" class="btn btn-dark" name="edit">Ver</a -->
                    <a href="javascript:sucuAEditar = '${snap.key}' ;pasarVariables('EdicionSucursal.html', 'sucuAEditar')" class="btn btn-info" name="edit">Editar</a>
                    <a href="#" class="btn btn-danger" name="delete">Borrar</a>
                </div>
            </div>
        `;
});

refListaSucursales.on('child_removed', snap =>{
    const tarjetaToRemove = document.getElementById(snap.key);
    tarjetaToRemove.remove();
});

                         
refListaCoordinadores.on('child_added', snap =>{ //2.2 Escucha nuevos Childs de COORDINADORES
    const itemCoordi = document.createElement('option');
    itemCoordi.id = snap.key;
    itemCoordi.value = snap.val().nombre;
    itemCoordi.innerText = snap.val().nombre;

    listaCoordi.appendChild(itemCoordi); 
});

////////////////////////////////funciones de interaccion de FORMS

function pasarVariables(pagina, nombres) {
  pagina +="?";
  nomVec = nombres.split(",");
  for (i=0; i<nomVec.length; i++)
    pagina += nomVec[i] + "=" + escape(eval(nomVec[i]))+"&";
  pagina = pagina.substring(0,pagina.length-1);
  location.href=pagina;
}