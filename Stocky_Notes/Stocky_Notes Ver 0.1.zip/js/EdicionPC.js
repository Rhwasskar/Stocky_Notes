//cacha variables del form de la pag anterior:
cadVariables = location.search.substring(1,location.search.length);
arrVariables = cadVariables.split("&");
for (i=0; i<arrVariables.length; i++) {
  arrVariableActual = arrVariables[i].split("=");
  if (isNaN(parseFloat(arrVariableActual[1])))
    eval(arrVariableActual[0]+"='"+unescape(arrVariableActual[1])+"';");
  else
    eval(arrVariableActual[0]+"="+arrVariableActual[1]+";");
}

var HWAEditar = '';  //esta es la var que se envía desde el boton editar
// const linkVolver = document.getElementById("linkVolver");
// linkVolver.href = `javascript:sucuAEditar = '${sucuAEditar}'; pasarVariables('EdicionSucursal.html', 'sucuAEditar')
// `;

//SDK Firebase y config 

var config = {
        apiKey: "AIzaSyBIWCjxJ4R4tsm1b-x1109xnMmPJVhPEFk",
        authDomain: "inventario-sucursales.firebaseapp.com",
        databaseURL: "https://inventario-sucursales.firebaseio.com",
        projectId: "inventario-sucursales",
        storageBucket: "inventario-sucursales.appspot.com",
        messagingSenderId: "27630270497"
        };
        firebase.initializeApp(config);

//fin firebase config

//---------------------Clases
class Computadora {
    constructor(marca, modelo, procesador, HDD, RAM, asignada, hostname, serialnumber){
  
    this.serialnumber = serialnumber;
    this.HDD = HDD;
    this.asignada = asignada;
    this.hostname = hostname;
    this.marca = marca;
    this.modelo = modelo;
    this.procesador = procesador;
    this.serialnumber = serialnumber;
    }

}

class UI{

	resetForm() {
        document.getElementById('formEdicion').reset();
        document.getElementById('selectComputadoras').value = '';
    }

	mostrarMensajeCarga(mensaje,css){

        const div = document.createElement('div');  		//creo un Div
        div.className = `alert alert-${css} mt-2`;			//le asigno clase para discriminar CSS
        div.appendChild(document.createTextNode(mensaje));	//inserto el texto dentro del div 
        // Mostrar
        const container = document.querySelector('.container');
        const app = document.querySelector('#App');
        // Insertar mensaje en la UI
        container.insertBefore(div, app);
        // Quitar el mensaje tras 3 segundos
        setTimeout(function () {
            document.querySelector('.alert').remove();
        }, 2000);
    }

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// funciones hacia la base de datos
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 

function updateSucursalBase(arbolitoSucursal) {

    var ClavePCAEditar = PCAEditar;

    var updates = {};
    updates['/informe-sucursal/PC/' + ClavePCAEditar] = arbolitoSucursal;

    return firebase.database().ref().update(updates);
    }  

    /////////////////////////////////////////      MAIN MAIN MAIN             //////////////////////////////////////////////////


//////////Eventos que involucran a la  Base
    
//----------------BOTONES--------------    

document.getElementById('botonActualizarEnBase').addEventListener('click', function ActualizarSucuEnBase(elemento){
        
        const marca = document.getElementById('marca').value,
            modelo = document.getElementById('modelo').value,
            serialnumber = document.getElementById('serialnumber').value;

        objetoPC = new Computadora(marca,modelo,serialnumber);
        
        const ui = new UI(); //creo una UI para mostrar mensajes, y borrar el contenido de más

        //validacion 
        if (marca === '' || modelo === '' || serialnumber === '') {
            ui.mostrarMensajeCarga('Debe completar todos los campos', 'danger');
        }else {
                                        // Guardando en BASE
        updateSucursalBase(objetoPC);
        ui.mostrarMensajeCarga('Elemento actualizado con éxito.', 'success');

        }
        //ui.resetForm(); //como el form me lo llena el evento de base no hace falta resetearlo.
        // elemento.preventDefault();

    });


// document.getElementById('botonMeterEnBase').addEventListener('click', function meterCompuEnBase(elemento){
        
//         const keyPCElegida =  document.getElementById('selectComputadoras').value;
//                 //aca tengo que conseguir la data de PC, para crear el objeto
//         var stringPCElegida = '/informe-sucursal/PC/'+keyPCElegida;
//         var refPCElegida = firebase.database().ref().child(stringPCElegida);



//         var objetoPC = new Computadora;
//         refPCElegida.on('value', snap =>{
//             objetoPC.HDD  = snap.child('HDD').val();
//             objetoPC.RAM  = snap.child('RAM').val();
//             objetoPC.asignada  = snap.child('asignada').val();
//             objetoPC.hostname  = snap.child('hostname').val();
//             objetoPC.marca  = snap.child('marca').val();
//             objetoPC.modelo  = snap.child('modelo').val();
//             objetoPC.procesador  = snap.child('procesador').val();
//             objetoPC.serialnumber  = snap.child('serialnumber').val();

//         });
      
        
        // const ui = new UI(); //creo una UI para mostrar mensajes, y borrar el contenido de más

        // //validacion 
        // if (keyPCElegida === '') {
        //     ui.mostrarMensajeCarga('Debe completar todos los campos', 'danger');
        // }else {
        //                                 // Guardando en BASE
        // agregarPCSucursalBase(objetoPC);
        // ui.mostrarMensajeCarga('Asociacion realizada con éxito.', 'success');

        // }
        // ui.resetForm();

    // });


//////boton volver
// document.addEventListener('click',"botonVolver",)
//--------------------FIN BOTONES


//----------------SINCRONIZACIÓN / MUESTRA DE ELEMENTO DE LA BASE--------------   
//1- referencio base

var stringKey = '/informe-sucursal/PC/'+PCAEditar;

const refPCAEditar = firebase.database().ref().child(stringKey);
                         
//LLeno el formulario Edición de SUCURSAL con los elementos de la sucursal de base

const formEdicion = document.getElementById("formEdicion");
var tituloPC = document.getElementById("tituloPC");

var marca = document.getElementById("marca");
var modelo = document.getElementById("modelo");
var serialnumber = document.getElementById("serialnumber");

var asignada = document.getElementById("asignada");
var procesador = document.getElementById("procesador");
var HDDTraido = document.getElementById("HDD");
var RAM = document.getElementById("RAM");
var hostname = document.getElementById("hostname");

PCsuelta = new Computadora(marca,modelo, serialnumber);


refPCAEditar.on('value', snap => {

    marca.value = snap.child('marca').val();
    modelo.value = snap.child('modelo').val();
    serialnumber.value = snap.child('serialnumber').val();
    asignada.value = snap.child('asignada').val();

    hostname.value = snap.child('hostname').val();
    procesador.value = snap.child('procesador').val();
    HDDTraido.value = snap.child('HDD').val();
    RAM.value = snap.child('RAM').val();

});


////////////////////////////////funciones de interaccion de FORMS

function pasarVariables(pagina, nombres) {
  pagina +="?";
  nomVec = nombres.split(",");
  for (i=0; i<nomVec.length; i++)
    pagina += nomVec[i] + "=" + escape(eval(nomVec[i]))+"&";
  pagina = pagina.substring(0,pagina.length-1);
  location.href=pagina;
}



